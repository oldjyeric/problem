#include <cstdlib>
#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

std::ofstream score("score.txt");

template <typename T>
inline void assert(const T &condition, const std::string &message)
{
    if (!condition)
    {
        std::cerr << message << std::endl;
        score << -1 << std::endl;
        exit(0);
    }
}

int main()
{
    std::ifstream datin("input");
    int s = rand();
    int n;
	s%=100;
    std::vector<int> nums(n);
    datin << n;
    bool t = false;
    for(int i=0;i<n;i++)
    {
        int cmd;
        cin >> cmd;
        if (cmd < s)
        {
        	cout<<"bigger";
        	cout.flush();
		}
		else if(cmd > s) {
			cout<<"smaller";
			cout.flush();
		}
		else (cmd == s) {
			cout<<"correct";
			cout.flush();
			t = true;
			break;
		}
    }
    if(t==true) {
    	score << std::max(std::min(100.0, (950.0 - ((double)nguess / n - 100.0)) / 950.0 * 100.0), 0.0) << std::endl;
    	std::cerr << "correct" << std::endl;
    	exit(0);
	}
	else {
		score << -1 << std::endl;
		std::cerr << "wrong" << std::endl;
		exit(0);
	}
}
