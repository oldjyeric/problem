#include <cstdio>
#include <ctime>
#include <cstdlib>
#include <climits>
#include <cstring>
#include <iostream>

#define MAXN 358
#define MAXC 48
using namespace std;

int f[MAXC][MAXC][MAXC][MAXC];
int a[MAXN];
int b[5];
int n, m;

int main()
{
    //freopen("tortoise.in", "r", stdin);
	//freopen("tortoise.out", "w", stdout);
	memset(f, 0, sizeof(f));
	memset(a, 0, sizeof(a));
	memset(b, 0, sizeof(b));
	
	int i, j, k, l;
	int max;
    scanf("%d%d", &n, &m);
    for(i = 1; i <= n; i++) 
        scanf("%d", a+i);
        
    for(i = 1; i <= m; i++) 
    {
        scanf("%d", &j);
        b[j]++;
    }
    
    f[0][0][0][0]=a[1];
    for(i = 0; i <= b[1]; i++)
        for(j = 0; j <= b[2]; j++)
            for(k = 0; k <= b[3]; k++)
                for(l = 0; l <= b[4]; l++)
                {
                    if(i > 0 || j > 0 || k > 0 || l > 0)
                    {
                        max = 0;
                        if(i > 0 && f[i-1][j][k][l] > max)
                            max = f[i-1][j][k][l];
                        if(j > 0 && f[i][j-1][k][l] > max)
                            max = f[i][j-1][k][l];
                        if(k > 0 && f[i][j][k-1][l] > max)
                            max = f[i][j][k-1][l];
                        if(l > 0 && f[i][j][k][l-1] > max)
                            max = f[i][j][k][l-1];
                        f[i][j][k][l] = max + a[i+j*2+k*3+l*4+1];
                    }
                }
    
    printf("%d\n", f[b[1]][b[2]][b[3]][b[4]]);
    
	return 0;
}
