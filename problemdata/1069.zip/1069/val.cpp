#include "testlib.h"
static const int MAXN = 355;
static const int MAXM = 128;

int n, m;
int a[MAXN], b[MAXM];

int main()
{
    registerValidation();

    n = inf.readInt(1, 350); inf.readSpace();
    m = inf.readInt(1, 120); inf.readEoln();
    for (int i = 0; i < n; ++i) {
        a[i] = inf.readInt(0, 100);
        if (i == n - 1) inf.readEoln(); else inf.readSpace();
    }
    for (int i = 0; i < m; ++i) {
        b[i] = inf.readInt(1, 4);
        if (i == m - 1) inf.readEoln(); else inf.readSpace();
    }
    inf.readEof();

    int sum = 0;
    for (int i = 0; i < m; ++i) sum += b[i];
    ensuref(sum == n - 1, "sum of b_i should be equal to n - 1");

    return 0;
}

